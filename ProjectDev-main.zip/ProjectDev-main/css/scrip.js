function disableButton() {
  document.getElementById("bk").disabled = true;
}